
function imprime(){
    let lg = document.getElementById("login").value
    let ps = document.getElementById("pass").value

    let senha = "snoopy"
     
    if(pass == senha){
        alert("Você está logado")
    } else{
        alert("Tente Novamente")
    }
}